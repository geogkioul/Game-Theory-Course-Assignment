function move = all_d(~, ~)
    % Always return move 'D'
    move = 'D';
end
function move = all_c(~, ~)
    % Always return move 'C'
    move = 'C';
end